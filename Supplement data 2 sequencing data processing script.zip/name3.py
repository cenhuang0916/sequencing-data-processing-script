import os
from collections import Counter


ca=open('../ca0.txt','r')
i=0
dict1={}
for line in ca:
    i=i+1
    li=str(line.split('\n')[0])
  #  print li
    dict1['%s'%(li)]='%d'%(i)
#print dict1 
ca.close()
#print dict1['AACCGA']


cb=open('../cb0.txt','r')
j=0
dict2={}
for line2 in cb:
    j=j+1
    li2=str(line2.split('\n')[0])
  #  print li
    k=j*1000
    dict2['%s'%(li2)]='%d'%(k)
cb.close()
#print dict2

cBA=open('./codeBA','r')
wr=open('./tBA3','w')
for cba in cBA:
    c1=str(cba.split('	')[0])
    c20=str(cba.split('	')[1])
    c2=str(c20.split('\n')[0])
#    print c1,dict1[c1],c2,dict[c2]
    try:
       wr.write(str(int(dict2[c1])))
    except:
       wr.write(c1)
    wr.write(' ')
    try:
       wr.write(str(int(dict1[c2])))
    except:
       wr.write(c2)
    wr.write(' ')
    try:
       wr.write(str(int(dict2[c1])+int(dict1[c2])))
    except:
       wr.write('err')
    wr.write(' ')   
    wr.write('\n')
cBA.close()
wr.close()

wr2=open('./tBA3','r')
F=[]
for ll in wr2:
    f=str(ll.split(' ')[2])
    F.append(f)
wr.close()

#print F

d=Counter(F)
#print d
dd=[]
add=[]
for k in d:
    print d[k],k
    if k != 'err':
       dd.append(int(k))

for i in range(1,101):
    m=i*1000
    for j in range(m+1,m+101):
        if j in dd:
           p=0
        else:
           add.append(j)
for i in add:
    print 0,i





