#!/bin/bash

set -e

for file in `ls *.fastq`
do
    mkdir $(echo $file | sed 's/......$//')
    cd ./$(echo $file | sed 's/......$//') 
    cp ../$file ./$file
    
    
    sed -i '/B/d' ./$file
    sed -i '/+/d' ./$file
    sed -i '/@/d' ./$file
    sed -i '/E/d' ./$file
    sed -i '/\//d' ./$file
    sed -i '/6/d' ./$file
    sed -i '/</d' ./$file
    sed -i '/#/d' ./$file


    sed -i 's/^..........//' ./$file
    sed -i 's/.........................................................$//' $file

    cat $file | sed -r 's/(......).*/\1/g' > seq2
    mv seq2 cb.txt
    
    sed -i 's/^............................//' $file
    mv $file ca.txt

    paste cb.txt ca.txt > codeBA

    python ../name3.py > freq.xls
    python ../rename.py
    paste freq.xls re.xls > fr.xls

    cd ..
done



