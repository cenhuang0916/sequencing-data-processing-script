import os
from collections import Counter


ca=open('../ca0.txt','r')
i=0
dict1={}
for line in ca:
    i=i+1
    li=str(line.split('\n')[0])
  #  print li
    dict1['%d'%(i)]='%s'%(li)
#print dict1 
ca.close()
#print dict1['AACCGA']


cb=open('../cb0.txt','r')
j=0
dict2={}
for line2 in cb:
    j=j+1
    li2=str(line2.split('\n')[0])
  #  print li
    k=j*1000
    dict2['%d'%(k)]='%s'%(li2)
cb.close()
#print dict2['1000']

cBA=open('./freq.xls','r')
wr=open('./re.xls','w')
for cba in cBA:
    c=str(cba.split(' ')[1])
    
 #   print c
    try:
       x=int(int(c)/1000)*1000
       y=int(int(c)%1000)
#     print x,y
       codeb=dict2[str(x)]
       codea=dict1[str(y)]
   #  print codeb,codea
       wr.write(codeb)
       wr.write(' ')
       wr.write(codea)
       wr.write(' ')
       wr.write('\n')
    except:
       err=1
       wr.write('err')
       wr.write(' ')
       wr.write('err')
       wr.write(' ')
       wr.write('\n')

wr.close()





